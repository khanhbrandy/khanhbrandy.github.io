import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;

public class GameOfLife {
	final private String IN_FILE = "input.txt";
	private int[] size = new int[2];
	private ArrayList<Integer> row_lives = new ArrayList<Integer>();
	private ArrayList<Integer> col_lives = new ArrayList<Integer>();
	private Board board = null;
	public static int[][] neighbours;

	private void readInput() {
		BufferedReader br = null;
		FileReader file = null;
		try {
			file = new FileReader(IN_FILE);
			br = new BufferedReader(file);

			String line;
			int count = 0;
			while ((line = br.readLine()) != null) {
				// Read the first 2 lines to get height and width of the board
				if (count < 2) {
					size[count] = Integer.parseInt(line);
				} else {
					// Read the remaining lines to get live cells
					String[] tokens = line.split(" ");
					row_lives.add(Integer.parseInt(tokens[0]));
					col_lives.add(Integer.parseInt(tokens[1]));
				}
				count++;
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void initBoard() {
		board = new Board(size[0], size[1]);
		neighbours = new int[board.getHeight()][board.getWidth()];
		// Initialize the board based on the original input
		for (int i = 0; i < row_lives.size(); i++) {
			board.getCells()[row_lives.get(i)][col_lives.get(i)] = '#';
		}
		board.print();
	}
	
	private void updateBoard() {
		LocalTime current = LocalTime.now(); 
		int s_current = current.getSecond();
		while (true) {
			LocalTime next_time = LocalTime.now(); 
			int s_next = next_time.getSecond();
			int diff = s_next-s_current;
			if (diff==1 || diff<0) {
				updateNeighbours();
				updateCells();
				s_current = s_next;
			}

		}
	}

	private int countNeighbours(int m, int n) {
		int n_neighbours = 0;
		int M = board.getHeight();
		int N = board.getWidth();
		int m_prev, m_next, n_prev, n_next;
		// Handle the edge cases (rows)
		if (m == 0) {
			m_prev = M - 1;
			m_next = m + 1;
		} else if (m == M - 1) {
			m_prev = m - 1;
			m_next = 0;
		// Handle the typical case
		} else {
			m_prev = m - 1;
			m_next = m + 1;
		}
		// Handle the edge cases (columns)
		if (n == 0) {
			n_prev = N - 1;
			n_next = n + 1;
		} else if (n == N - 1) {
			n_prev = n - 1;
			n_next = 0;
		// Handle the typical case
		} else {
			n_prev = n - 1;
			n_next = n + 1;
		}
		// Locate neighborhood
		int[] rows = { m_prev, m, m_next };
		int[] cols = { n_prev, n, n_next };
		for (int i = 0; i < rows.length; i++) {
			for (int j = 0; j < cols.length; j++) {
				if (board.getCells()[rows[i]][cols[j]] == '#') {
					n_neighbours += 1;
				}
			}
		}
		// Exclude the cell itself
		if (board.getCells()[m][n] == '#') {
			n_neighbours -= 1;
		}
		return n_neighbours;
	}

	private void updateNeighbours() {
		// Update the neighbor 2-D array
		for (int m = 0; m < neighbours.length; m++) {
			for (int n = 0; n < neighbours[1].length; n++) {
				neighbours[m][n] = countNeighbours(m, n);
			}
		}
	}
	
	private void updateCells() {
		// Update based on the new neighbor count of each cell
		for (int i = 0; i < board.getHeight(); i++) {
			for (int j = 0; j < board.getWidth(); j++) {
				if (board.getCells()[i][j] == '#') {
					if (neighbours[i][j]==2 || neighbours[i][j]==3) {
						board.getCells()[i][j] = '#';
					} else {
						board.getCells()[i][j] = ' ';
					}
				} else {
					if (neighbours[i][j]==3) {
						board.getCells()[i][j] = '#';
					}
				} 
			}
		}
		board.print();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GameOfLife game = new GameOfLife();
		game.readInput();
		game.initBoard();
		game.updateBoard();
	}
}
